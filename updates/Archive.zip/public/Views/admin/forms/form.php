<?php
/** Requires $formRecord, $roles, $errors, $form in scope. */
use App\Models\FormFieldTypes;

require __DIR__ . '/../layout-header.php';
$action = $formRecord ? url('/admin/forms/' . (int) $formRecord['id']) : url('/admin/forms');
$fields = $form['fields'] ?? [];
if (!$fields) {
    $fields = [['label' => '', 'field_type' => 'text', 'is_required' => false, 'options' => ['', ''], 'placeholder' => '', 'help_text' => '']];
}
$fieldGroups = FormFieldTypes::groups();
$choiceTypes = ['dropdown', 'multiselect', 'radio', 'checkboxes'];

function fieldChoices(array $field): array
{
    $choices = $field['choices'] ?? $field['options'] ?? [];
    if (!is_array($choices)) {
        $choices = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $choices) ?: [])));
    }
    $choices = array_values($choices);
    if (count($choices) < 2) {
        $choices = array_pad($choices, 2, '');
    }
    return $choices;
}
?>

<form method="post" action="<?= $action ?>" class="max-w-4xl space-y-6" id="form-builder">
  <?= csrfField() ?>
  <?php foreach ($errors as $err): ?>
    <div class="flash-error"><?= e($err) ?></div>
  <?php endforeach; ?>

  <div class="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm space-y-4">
    <h2 class="font-serif-heading text-lg font-bold border-b border-neutral-100 pb-3">Form</h2>
    <div>
      <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Form title</label>
      <input type="text" name="title" required value="<?= e($form['title'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
    </div>
    <div>
      <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Description</label>
      <textarea name="description" rows="3" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm"><?= e($form['description'] ?? '') ?></textarea>
    </div>
    <input type="hidden" name="is_active" value="0" />
    <label class="flex items-center gap-2 text-sm font-bold">
      <input type="checkbox" name="is_active" value="1" <?= !empty($form['is_active']) ? 'checked' : '' ?> class="h-4 w-4" />
      Active — show this form to assigned roles
    </label>
    <div class="pt-2">
      <p class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">What this form is for</p>
      <div class="mt-2 grid gap-2 sm:grid-cols-2">
        <label class="flex items-start gap-2 rounded-lg border border-neutral-300 bg-white p-2.5 text-sm font-semibold">
          <input type="radio" name="purpose" value="profile" <?= ($form['purpose'] ?? 'profile') !== 'course' ? 'checked' : '' ?> class="mt-0.5 h-4 w-4" />
          <span>Profile details — appears on the user’s profile page</span>
        </label>
        <label class="flex items-start gap-2 rounded-lg border border-neutral-300 bg-white p-2.5 text-sm font-semibold">
          <input type="radio" name="purpose" value="course" <?= ($form['purpose'] ?? '') === 'course' ? 'checked' : '' ?> class="mt-0.5 h-4 w-4" />
          <span>Course creation — approved tutors use this to create courses</span>
        </label>
      </div>
    </div>
  </div>

  <div class="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm space-y-4">
    <h2 class="font-serif-heading text-lg font-bold border-b border-neutral-100 pb-3">Assign to roles</h2>
      <p class="text-xs font-medium" style="color:var(--ke-muted)">Profile forms attach to matching users’ profile pages. Course forms appear when approved tutors create a course. Assign a course form to the Trainer / Tutor / Teacher role and include a Category field plus file uploads.</p>
    <div class="grid gap-2 sm:grid-cols-2">
      <?php foreach ($roles as $role): ?>
        <label class="flex items-center gap-2 rounded-lg border border-neutral-300 bg-white p-2.5 text-sm font-semibold">
          <input type="checkbox" name="role_ids[]" value="<?= (int) $role['id'] ?>" <?= in_array((int) $role['id'], array_map('intval', $form['role_ids'] ?? []), true) ? 'checked' : '' ?> class="h-4 w-4" />
          <?= e($role['name']) ?>
        </label>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm space-y-4">
    <div class="border-b border-neutral-100 pb-3">
      <h2 class="font-serif-heading text-lg font-bold">Fields</h2>
      <p class="text-xs font-medium mt-1" style="color:var(--ke-muted)">Pick a type the way WordPress form builders do. Drag a field to reposition it. Organisation branches lets organisation admins list name, location, and extra details you add, on their original profile form. Organisation category loads categories each organisation lists — approved tutors only see categories for organisations they belong to. Documents accepts PDFs, images, and Word files.</p>
    </div>
    <div id="fields-list" class="space-y-4">
      <?php foreach ($fields as $index => $field):
        $type = $field['field_type'] ?? 'text';
        $choices = fieldChoices($field);
        $needsChoices = in_array($type, $choiceTypes, true);
        $rangeMin = $field['range_min'] ?? '';
        $rangeMax = $field['range_max'] ?? '';
        if ($type === 'range' && $rangeMin === '') {
            $rangeMin = '0';
        }
        if ($type === 'range' && $rangeMax === '') {
            $rangeMax = '100';
        }
        if ($type === 'rating' && $rangeMin === '') {
            $rangeMin = '1';
        }
        if ($type === 'rating' && $rangeMax === '') {
            $rangeMax = '5';
        }
        $columns = max(1, min(3, (int) ($field['columns'] ?? 1)));
        $orgMode = (($field['org_mode'] ?? '') === 'multiple') ? 'multiple' : 'single';
      ?>
        <div class="field-row rounded-lg border p-4 space-y-3" data-field style="border-color:var(--ke-line)">
          <input type="hidden" name="fields[<?= (int) $index ?>][field_key]" value="<?= e($field['field_key'] ?? '') ?>" data-name="field_key" />
          <div class="flex items-start gap-3">
            <button type="button" class="field-drag-handle" draggable="true" title="Drag to reorder" aria-label="Drag to reorder">
              <span aria-hidden="true">⋮⋮</span>
            </button>
            <div class="min-w-0 flex-1 space-y-3">
          <div class="grid gap-3 sm:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_auto]">
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Field name</label>
              <input type="text" name="fields[<?= (int) $index ?>][label]" value="<?= e($field['label'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="e.g. National ID" />
            </div>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Field type</label>
              <select name="fields[<?= (int) $index ?>][field_type]" class="field-type mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
                <?php foreach ($fieldGroups as $group => $types): ?>
                  <optgroup label="<?= e($group) ?>">
                    <?php foreach ($types as $value => $label): ?>
                      <option value="<?= e($value) ?>" <?= $type === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                  </optgroup>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="flex flex-wrap items-end gap-2">
              <button type="button" class="move-field-up btn-secondary" style="padding:0.4rem 0.7rem;">Up</button>
              <button type="button" class="move-field-down btn-secondary" style="padding:0.4rem 0.7rem;">Down</button>
              <button type="button" class="remove-field btn-danger">Remove</button>
            </div>
          </div>
          <div class="grid gap-3 sm:grid-cols-2">
            <div class="placeholder-wrap <?= FormFieldTypes::needsPlaceholder($type) ? '' : 'hidden' ?>">
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Placeholder</label>
              <input type="text" name="fields[<?= (int) $index ?>][placeholder]" value="<?= e($field['placeholder'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
            </div>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Help text</label>
              <input type="text" name="fields[<?= (int) $index ?>][help_text]" value="<?= e($field['help_text'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="Shown under the field" />
            </div>
          </div>
          <label class="required-wrap flex items-center gap-2 text-sm font-bold <?= FormFieldTypes::isLayout($type) ? 'hidden' : '' ?>">
            <input type="checkbox" name="fields[<?= (int) $index ?>][is_required]" value="1" <?= !empty($field['is_required']) ? 'checked' : '' ?> class="h-4 w-4" />
            Required
          </label>
          <div class="choices-wrap <?= $needsChoices || $type === 'branches' ? '' : 'hidden' ?>">
            <div class="choices-copy-default <?= $type === 'branches' ? 'hidden' : '' ?>">
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Choice values (what the user can pick)</label>
              <p class="field-hint">Add each option. You can change these later from this same form.</p>
            </div>
            <div class="choices-copy-branches <?= $type === 'branches' ? '' : 'hidden' ?>">
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Extra details on each branch</label>
              <p class="field-hint">Name and location are always included. Add extra values here (phone, contact person, hours, and anything else). Organisation admins fill them in on the original profile form.</p>
            </div>
            <div class="choices-list mt-2">
              <?php foreach ($choices as $choice): ?>
                <div class="choice-row">
                  <input type="text" data-choice="1" name="fields[<?= (int) $index ?>][choices][]" value="<?= e($choice) ?>" class="rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="e.g. Nairobi" />
                  <button type="button" class="remove-choice btn-danger" style="padding:0.4rem 0.7rem;">Remove</button>
                </div>
              <?php endforeach; ?>
            </div>
            <button type="button" class="add-choice btn-secondary mt-2" style="padding:0.4rem 0.75rem;">Add choice</button>
            <div class="choice-settings mt-3 space-y-3 rounded-lg p-3 <?= $type === 'branches' ? 'hidden' : '' ?>" style="background:#f6f7f4;border:1px solid var(--ke-line)">
              <label class="allow-other-wrap flex items-center gap-2 text-sm font-bold <?= FormFieldTypes::allowsOther($type) ? '' : 'hidden' ?>">
                <input type="checkbox" name="fields[<?= (int) $index ?>][allow_other]" value="1" <?= !empty($field['allow_other']) ? 'checked' : '' ?> class="h-4 w-4" data-name="allow_other" />
                Allow “Other” with a write-in box
              </label>
              <div class="columns-wrap <?= FormFieldTypes::hasColumns($type) ? '' : 'hidden' ?>">
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Layout</label>
                <select name="fields[<?= (int) $index ?>][columns]" data-name="columns" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
                  <option value="1" <?= $columns === 1 ? 'selected' : '' ?>>One column</option>
                  <option value="2" <?= $columns === 2 ? 'selected' : '' ?>>Two columns</option>
                  <option value="3" <?= $columns === 3 ? 'selected' : '' ?>>Three columns</option>
                </select>
              </div>
              <div class="minmax-wrap grid gap-3 sm:grid-cols-2 <?= FormFieldTypes::hasMinMaxSelect($type) ? '' : 'hidden' ?>">
                <div>
                  <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Minimum selections</label>
                  <input type="number" min="0" name="fields[<?= (int) $index ?>][min_select]" data-name="min_select" value="<?= e((string) ($field['min_select'] ?? 0)) ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
                </div>
                <div>
                  <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Maximum selections</label>
                  <input type="number" min="0" name="fields[<?= (int) $index ?>][max_select]" data-name="max_select" value="<?= e((string) ($field['max_select'] ?? 0)) ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
                  <p class="field-hint">0 means no limit.</p>
                </div>
              </div>
              <label class="select-all-wrap flex items-center gap-2 text-sm font-bold <?= $type === 'checkboxes' ? '' : 'hidden' ?>">
                <input type="checkbox" name="fields[<?= (int) $index ?>][select_all]" value="1" <?= !empty($field['select_all']) ? 'checked' : '' ?> class="h-4 w-4" data-name="select_all" />
                Show “Select all”
              </label>
            </div>
          </div>
          <div class="range-wrap grid gap-3 sm:grid-cols-2 <?= FormFieldTypes::needsRange($type) ? '' : 'hidden' ?>">
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Minimum</label>
              <input type="number" name="fields[<?= (int) $index ?>][range_min]" value="<?= e((string) $rangeMin) ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
            </div>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Maximum</label>
              <input type="number" name="fields[<?= (int) $index ?>][range_max]" value="<?= e((string) $rangeMax) ?>" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
            </div>
          </div>
          <div class="org-mode-wrap rounded-lg p-3 <?= $type === 'organisation' ? '' : 'hidden' ?>" style="background:#f6f7f4;border:1px solid var(--ke-line)">
            <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Organisation selection</label>
            <select name="fields[<?= (int) $index ?>][org_mode]" data-name="org_mode" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
              <option value="single" <?= $orgMode === 'single' ? 'selected' : '' ?>>One organisation</option>
              <option value="multiple" <?= $orgMode === 'multiple' ? 'selected' : '' ?>>Multiple organisations</option>
            </select>
            <p class="field-hint">People pick from organisations saved in the database. For tutor registration, each selected organisation must approve them.</p>
          </div>
          <div class="category-wrap rounded-lg p-3 <?= $type === 'category' ? '' : 'hidden' ?>" style="background:#f6f7f4;border:1px solid var(--ke-line)">
            <p class="text-sm font-semibold">Organisation categories</p>
            <p class="field-hint">This field lists categories each organisation has added. Approved tutors only see categories for organisations they belong to. Use it on a course-creation form assigned to trainers.</p>
          </div>
          <div class="duration-wrap rounded-lg p-3 <?= $type === 'duration' ? '' : 'hidden' ?>" style="background:#f6f7f4;border:1px solid var(--ke-line)">
            <p class="text-sm font-semibold">Attachment duration</p>
            <p class="field-hint">Use this on the Attachment Trainer profile form. They enter a start and end date for the placement period.</p>
          </div>
          <div class="branch-wrap rounded-lg p-3 <?= $type === 'branches' ? '' : 'hidden' ?>" style="background:#f6f7f4;border:1px solid var(--ke-line)">
            <p class="text-sm font-semibold">Organisation branches</p>
            <p class="field-hint">Put this on the organisation admin profile form. They list each branch (name and location) plus the extra details you add above. Saving the profile also updates the Branches page.</p>
          </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <button type="button" id="add-field" class="btn-secondary">Add field</button>
  </div>

  <div class="flex items-center gap-3">
    <button type="submit" class="btn-primary"><?= $formRecord ? 'Save form' : 'Create form' ?></button>
    <a href="<?= url('/admin/forms') ?>" class="btn-secondary">Cancel</a>
  </div>
</form>

<template id="field-template">
  <div class="field-row rounded-lg border p-4 space-y-3" data-field style="border-color:var(--ke-line)">
    <input type="hidden" data-name="field_key" value="" />
    <div class="flex items-start gap-3">
      <button type="button" class="field-drag-handle" draggable="true" title="Drag to reorder" aria-label="Drag to reorder">
        <span aria-hidden="true">⋮⋮</span>
      </button>
      <div class="min-w-0 flex-1 space-y-3">
    <div class="grid gap-3 sm:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_auto]">
      <div>
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Field name</label>
        <input type="text" data-name="label" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="e.g. National ID" />
      </div>
      <div>
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Field type</label>
        <select data-name="field_type" class="field-type mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
          <?php foreach ($fieldGroups as $group => $types): ?>
            <optgroup label="<?= e($group) ?>">
              <?php foreach ($types as $value => $label): ?>
                <option value="<?= e($value) ?>"><?= e($label) ?></option>
              <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="flex flex-wrap items-end gap-2">
        <button type="button" class="move-field-up btn-secondary" style="padding:0.4rem 0.7rem;">Up</button>
        <button type="button" class="move-field-down btn-secondary" style="padding:0.4rem 0.7rem;">Down</button>
        <button type="button" class="remove-field btn-danger">Remove</button>
      </div>
    </div>
    <div class="grid gap-3 sm:grid-cols-2">
      <div class="placeholder-wrap">
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Placeholder</label>
        <input type="text" data-name="placeholder" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
      </div>
      <div>
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Help text</label>
        <input type="text" data-name="help_text" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="Shown under the field" />
      </div>
    </div>
    <label class="required-wrap flex items-center gap-2 text-sm font-bold">
      <input type="checkbox" data-name="is_required" value="1" class="h-4 w-4" />
      Required
    </label>
    <div class="choices-wrap hidden">
      <div class="choices-copy-default">
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Choice values (what the user can pick)</label>
        <p class="field-hint">Add each option. You can change these later from this same form.</p>
      </div>
      <div class="choices-copy-branches hidden">
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Extra details on each branch</label>
        <p class="field-hint">Name and location are always included. Add extra values here (phone, contact person, hours, and anything else). Organisation admins fill them in on the original profile form.</p>
      </div>
      <div class="choices-list mt-2">
        <div class="choice-row">
          <input type="text" data-choice="1" class="rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="e.g. Nairobi" />
          <button type="button" class="remove-choice btn-danger" style="padding:0.4rem 0.7rem;">Remove</button>
        </div>
        <div class="choice-row">
          <input type="text" data-choice="1" class="rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" placeholder="e.g. Mombasa" />
          <button type="button" class="remove-choice btn-danger" style="padding:0.4rem 0.7rem;">Remove</button>
        </div>
      </div>
      <button type="button" class="add-choice btn-secondary mt-2" style="padding:0.4rem 0.75rem;">Add choice</button>
      <div class="choice-settings mt-3 space-y-3 rounded-lg p-3" style="background:#f6f7f4;border:1px solid var(--ke-line)">
        <label class="allow-other-wrap flex items-center gap-2 text-sm font-bold">
          <input type="checkbox" value="1" class="h-4 w-4" data-name="allow_other" />
          Allow “Other” with a write-in box
        </label>
        <div class="columns-wrap hidden">
          <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Layout</label>
          <select data-name="columns" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
            <option value="1">One column</option>
            <option value="2">Two columns</option>
            <option value="3">Three columns</option>
          </select>
        </div>
        <div class="minmax-wrap grid gap-3 sm:grid-cols-2 hidden">
          <div>
            <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Minimum selections</label>
            <input type="number" min="0" data-name="min_select" value="0" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
          </div>
          <div>
            <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Maximum selections</label>
            <input type="number" min="0" data-name="max_select" value="0" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
            <p class="field-hint">0 means no limit.</p>
          </div>
        </div>
        <label class="select-all-wrap flex items-center gap-2 text-sm font-bold hidden">
          <input type="checkbox" value="1" class="h-4 w-4" data-name="select_all" />
          Show “Select all”
        </label>
      </div>
    </div>
    <div class="range-wrap grid gap-3 sm:grid-cols-2 hidden">
      <div>
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Minimum</label>
        <input type="number" data-name="range_min" value="" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
      </div>
      <div>
        <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Maximum</label>
        <input type="number" data-name="range_max" value="" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm" />
      </div>
    </div>
    <div class="org-mode-wrap hidden rounded-lg p-3" style="background:#f6f7f4;border:1px solid var(--ke-line)">
      <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Organisation selection</label>
      <select data-name="org_mode" class="mt-1 w-full rounded-lg border border-neutral-300 bg-white p-2.5 text-sm">
        <option value="single">One organisation</option>
        <option value="multiple">Multiple organisations</option>
      </select>
      <p class="field-hint">People pick from organisations saved in the database. For tutor registration, each selected organisation must approve them.</p>
    </div>
    <div class="category-wrap hidden rounded-lg p-3" style="background:#f6f7f4;border:1px solid var(--ke-line)">
      <p class="text-sm font-semibold">Organisation categories</p>
      <p class="field-hint">This field lists categories each organisation has added. Approved tutors only see categories for organisations they belong to. Use it on a course-creation form assigned to trainers.</p>
    </div>
    <div class="duration-wrap hidden rounded-lg p-3" style="background:#f6f7f4;border:1px solid var(--ke-line)">
      <p class="text-sm font-semibold">Attachment duration</p>
      <p class="field-hint">Use this on the Attachment Trainer profile form. They enter a start and end date for the placement period.</p>
    </div>
    <div class="branch-wrap hidden rounded-lg p-3" style="background:#f6f7f4;border:1px solid var(--ke-line)">
      <p class="text-sm font-semibold">Organisation branches</p>
      <p class="field-hint">Put this on the organisation admin profile form. They list each branch (name and location) plus the extra details you add above. Saving the profile also updates the Branches page.</p>
    </div>
      </div>
    </div>
  </div>
</template>

<script>
(function () {
  var list = document.getElementById('fields-list');
  var template = document.getElementById('field-template');
  var addBtn = document.getElementById('add-field');
  var choiceTypes = { dropdown: 1, multiselect: 1, radio: 1, checkboxes: 1 };
  var placeholderTypes = { text: 1, paragraph: 1, email: 1, phone: 1, url: 1, number: 1, password: 1, hidden: 1, signature: 1, list: 1 };
  var layoutTypes = { heading: 1, instructions: 1 };
  var rangeTypes = { range: 1, number: 1, rating: 1 };
  var otherTypes = { dropdown: 1, radio: 1, checkboxes: 1 };
  var columnTypes = { radio: 1, checkboxes: 1 };
  var minmaxTypes = { checkboxes: 1, multiselect: 1 };
  var rangeDefaults = { range: ['0', '100'], rating: ['1', '5'], number: ['', ''] };
  var dragEl = null;

  function reindex() {
    Array.prototype.forEach.call(list.querySelectorAll('[data-field]'), function (row, index) {
      row.querySelectorAll('[data-choice]').forEach(function (el) {
        el.setAttribute('name', 'fields[' + index + '][choices][]');
      });
      row.querySelectorAll('[name], [data-name]').forEach(function (el) {
        if (el.hasAttribute('data-choice')) return;
        var key = el.getAttribute('data-name') || (el.getAttribute('name') || '').replace(/^fields\[\d+\]\[([^\]]+)\](?:\[\])?$/, '$1');
        if (!key || key === 'choices') return;
        el.setAttribute('name', 'fields[' + index + '][' + key + ']');
      });
    });
  }

  function syncRow(row) {
    var type = row.querySelector('.field-type');
    var value = type ? type.value : 'text';
    var choices = row.querySelector('.choices-wrap');
    var range = row.querySelector('.range-wrap');
    var placeholder = row.querySelector('.placeholder-wrap');
    var required = row.querySelector('.required-wrap');
    var allowOther = row.querySelector('.allow-other-wrap');
    var columns = row.querySelector('.columns-wrap');
    var minmax = row.querySelector('.minmax-wrap');
    var selectAll = row.querySelector('.select-all-wrap');
    var orgMode = row.querySelector('.org-mode-wrap');
    var categoryWrap = row.querySelector('.category-wrap');
    var durationWrap = row.querySelector('.duration-wrap');
    var branchWrap = row.querySelector('.branch-wrap');
    var choiceSettings = row.querySelector('.choice-settings');
    var choicesDefault = row.querySelector('.choices-copy-default');
    var choicesBranches = row.querySelector('.choices-copy-branches');
    if (choices) choices.classList.toggle('hidden', !choiceTypes[value] && value !== 'branches');
    if (range) range.classList.toggle('hidden', !rangeTypes[value]);
    if (placeholder) placeholder.classList.toggle('hidden', !placeholderTypes[value]);
    if (required) required.classList.toggle('hidden', !!layoutTypes[value]);
    if (allowOther) allowOther.classList.toggle('hidden', !otherTypes[value]);
    if (columns) columns.classList.toggle('hidden', !columnTypes[value]);
    if (minmax) minmax.classList.toggle('hidden', !minmaxTypes[value]);
    if (selectAll) selectAll.classList.toggle('hidden', value !== 'checkboxes');
    if (orgMode) orgMode.classList.toggle('hidden', value !== 'organisation');
    if (categoryWrap) categoryWrap.classList.toggle('hidden', value !== 'category');
    if (durationWrap) durationWrap.classList.toggle('hidden', value !== 'duration');
    if (branchWrap) branchWrap.classList.toggle('hidden', value !== 'branches');
    if (choiceSettings) choiceSettings.classList.toggle('hidden', !choiceTypes[value]);
    if (choicesDefault) choicesDefault.classList.toggle('hidden', value === 'branches');
    if (choicesBranches) choicesBranches.classList.toggle('hidden', value !== 'branches');
    if (range && rangeTypes[value] && rangeDefaults[value]) {
      var minInput = range.querySelector('[name$="[range_min]"], [data-name="range_min"]');
      var maxInput = range.querySelector('[name$="[range_max]"], [data-name="range_max"]');
      if (minInput && minInput.value === '' && rangeDefaults[value][0] !== '') minInput.value = rangeDefaults[value][0];
      if (maxInput && maxInput.value === '' && rangeDefaults[value][1] !== '') maxInput.value = rangeDefaults[value][1];
    }
  }

  function moveRow(row, direction) {
    if (direction < 0 && row.previousElementSibling) {
      list.insertBefore(row, row.previousElementSibling);
    } else if (direction > 0 && row.nextElementSibling) {
      list.insertBefore(row.nextElementSibling, row);
    }
    reindex();
  }

  function bindDrag(row) {
    var handle = row.querySelector('.field-drag-handle');
    if (!handle) return;
    handle.addEventListener('dragstart', function (event) {
      dragEl = row;
      row.classList.add('is-dragging');
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', 'field');
    });
    handle.addEventListener('dragend', function () {
      if (dragEl) dragEl.classList.remove('is-dragging');
      list.querySelectorAll('.drag-over').forEach(function (el) { el.classList.remove('drag-over'); });
      dragEl = null;
      reindex();
    });
  }

  function bindRow(row) {
    var type = row.querySelector('.field-type');
    if (type) type.addEventListener('change', function () { syncRow(row); });
    syncRow(row);
    bindDrag(row);

    var remove = row.querySelector('.remove-field');
    if (remove) {
      remove.addEventListener('click', function () {
        if (list.querySelectorAll('[data-field]').length === 1) return;
        row.remove();
        reindex();
      });
    }

    var up = row.querySelector('.move-field-up');
    if (up) up.addEventListener('click', function () { moveRow(row, -1); });
    var down = row.querySelector('.move-field-down');
    if (down) down.addEventListener('click', function () { moveRow(row, 1); });

    row.addEventListener('click', function (event) {
      if (event.target.classList.contains('add-choice')) {
        var holder = row.querySelector('.choices-list');
        var first = holder.querySelector('.choice-row');
        var copy = first.cloneNode(true);
        var input = copy.querySelector('input');
        if (input) input.value = '';
        holder.appendChild(copy);
        reindex();
      }
      if (event.target.classList.contains('remove-choice')) {
        var holder = row.querySelector('.choices-list');
        if (holder.querySelectorAll('.choice-row').length === 1) return;
        event.target.closest('.choice-row').remove();
        reindex();
      }
    });
  }

  list.addEventListener('dragover', function (event) {
    event.preventDefault();
    if (!dragEl) return;
    var row = event.target.closest('[data-field]');
    if (!row || row === dragEl) return;
    var rect = row.getBoundingClientRect();
    var before = (event.clientY - rect.top) < rect.height / 2;
    list.insertBefore(dragEl, before ? row : row.nextSibling);
  });
  list.addEventListener('drop', function (event) {
    event.preventDefault();
  });

  Array.prototype.forEach.call(list.querySelectorAll('[data-field]'), bindRow);
  addBtn.addEventListener('click', function () {
    var node = template.content.firstElementChild.cloneNode(true);
    list.appendChild(node);
    bindRow(node);
    reindex();
    node.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  reindex();
})();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
