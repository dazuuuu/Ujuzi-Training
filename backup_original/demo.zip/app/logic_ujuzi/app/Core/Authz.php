<?php

namespace App\Core;

use App\Models\OrganisationMembership;
use App\Models\Role;
use App\Models\User;

class Authz
{
    public static function canManageUsers(array $actor): bool
    {
        return !empty($actor['can_manage_users']) && !empty($actor['has_admin_features']);
    }

    public static function manageableRoles(array $actor): array
    {
        $slugs = $actor['managed_role_slugs'] ?? [];
        if (!$slugs) {
            return [];
        }
        return Role::findBySlugs($slugs);
    }

    public static function canManageRole(array $actor, string $roleSlug): bool
    {
        return in_array($roleSlug, $actor['managed_role_slugs'] ?? [], true);
    }

    public static function canAccessUser(array $actor, array $target): bool
    {
        if ((int) $actor['id'] === (int) $target['id']) {
            return true;
        }
        if (!self::canManageUsers($actor)) {
            return false;
        }
        $orgId = (int) ($actor['organisation_id'] ?? 0);
        if ($orgId < 1) {
            return false;
        }
        $sameOrg = (int) ($target['organisation_id'] ?? 0) === $orgId;
        $approvedMember = false;
        try {
            $approvedMember = OrganisationMembership::isApproved((int) $target['id'], $orgId);
        } catch (\Throwable $e) {
            $approvedMember = false;
        }
        if (!$sameOrg && !$approvedMember) {
            return false;
        }
        return self::canManageRole($actor, $target['role_slug'] ?? '');
    }

    public static function scopedUsers(array $actor): array
    {
        if (!self::canManageUsers($actor)) {
            return [];
        }
        $orgId = (int) ($actor['organisation_id'] ?? 0);
        if ($orgId < 1) {
            return [];
        }
        $allowed = $actor['managed_role_slugs'] ?? [];
        try {
            $users = User::allForOrganisation($orgId);
        } catch (\Throwable $e) {
            $users = User::all($orgId);
        }
        return array_values(array_filter(
            $users,
            fn(array $user): bool => in_array($user['role_slug'], $allowed, true)
        ));
    }

    public static function isOrganisationAdmin(array $actor): bool
    {
        return ($actor['role_slug'] ?? '') === 'organisation_admin' && !empty($actor['organisation_id']);
    }

    public static function approvedOrganisationIds(array $actor): array
    {
        $ids = [];
        try {
            $ids = OrganisationMembership::approvedOrganisationIds((int) $actor['id']);
        } catch (\Throwable $e) {
            $ids = [];
        }
        if (!$ids && !empty($actor['organisation_id']) && OrganisationMembership::isTrainerRole((string) ($actor['role_slug'] ?? ''))) {
            $ids[] = (int) $actor['organisation_id'];
        }
        return array_values(array_unique(array_filter($ids)));
    }

    public static function isStudent(array $actor): bool
    {
        return ($actor['role_slug'] ?? '') === 'student';
    }

    /** Categories a student is approved for, across every organisation they're approved under. */
    public static function approvedCategoryIds(array $actor): array
    {
        $ids = [];
        try {
            foreach (OrganisationMembership::forUser((int) $actor['id']) as $membership) {
                if (($membership['status'] ?? '') === OrganisationMembership::STATUS_APPROVED) {
                    foreach ($membership['category_ids'] ?? [] as $categoryId) {
                        $ids[] = (int) $categoryId;
                    }
                }
            }
        } catch (\Throwable $e) {
            $ids = [];
        }
        return array_values(array_unique(array_filter($ids)));
    }

    public static function learnerOrganisationIds(array $actor): array
    {
        // Only approved memberships count — a pending join request must not
        // unlock that organisation's strict-visibility courses early.
        $ids = [];
        try {
            $ids = OrganisationMembership::approvedOrganisationIds((int) $actor['id']);
        } catch (\Throwable $e) {
            $ids = [];
        }
        if (!$ids && !empty($actor['organisation_id'])) {
            $ids[] = (int) $actor['organisation_id'];
        }
        return array_values(array_unique(array_filter($ids)));
    }

    public static function canCreateCourses(array $actor): bool
    {
        return OrganisationMembership::isTrainerRole((string) ($actor['role_slug'] ?? ''))
            && self::approvedOrganisationIds($actor) !== [];
    }

    public static function canViewCourses(array $actor): bool
    {
        return self::isOrganisationAdmin($actor)
            || ($actor['role_slug'] ?? '') === 'trainer'
            || ($actor['role_slug'] ?? '') === 'course_branch_admin'
            || self::isStudent($actor);
    }

    public static function canManageBranches(array $actor): bool
    {
        return self::isOrganisationAdmin($actor) || ($actor['role_slug'] ?? '') === 'attachment_trainer';
    }

    public static function canAccessCourse(array $actor, array $course): bool
    {
        // Students only reach courses Super Admin approved.
        if (self::isStudent($actor) && isset($course['approval_status']) && $course['approval_status'] !== 'approved') {
            return false;
        }
        if (self::isOrganisationAdmin($actor) && (int) $course['organisation_id'] === (int) $actor['organisation_id']) {
            return true;
        }
        if ((int) ($course['trainer_user_id'] ?? 0) === (int) $actor['id'] && self::canCreateCourses($actor)) {
            return true;
        }
        // A branch admin sees (but doesn't edit) the courses their branch's tutors offer.
        if (($actor['role_slug'] ?? '') === 'course_branch_admin' && !empty($course['branch_id'])
            && in_array((int) $course['branch_id'], \App\Services\BranchScope::branchIds((int) $actor['id']), true)) {
            return true;
        }
        if (!self::isStudent($actor) || empty($course['is_published'])) {
            return false;
        }
        if (($course['visibility'] ?? 'strict') === 'global') {
            return true;
        }
        // Every course of an organisation that approved the student — the same
        // rule as Course::forLearner(), so the list and the course page agree.
        return in_array((int) $course['organisation_id'], self::learnerOrganisationIds($actor), true);
    }

    public static function canEditCourse(array $actor, array $course): bool
    {
        return (int) ($course['trainer_user_id'] ?? 0) === (int) $actor['id'] && self::canCreateCourses($actor);
    }
}
