<?php

namespace App\Controllers\Account;

use App\Core\Authz;
use App\Core\Request;
use App\Models\OrganisationBranch;
use App\Models\OrganisationCategory;

class CategoryController extends BaseAccountController
{
    public function index(): void
    {
        $this->requireOrgAdmin();
        $this->render('account.categories.index', [
            'pageTitle' => 'Categories',
            'activeNav' => 'categories',
            'categories' => $this->visibleCategories(),
        ]);
    }

    public function create(): void
    {
        $this->requireOrgAdmin();
        $this->render('account.categories.form', [
            'pageTitle' => 'Add category',
            'activeNav' => 'categories',
            'category' => null,
            'errors' => [],
            'form' => $this->blankForm(),
        ]);
    }

    public function store(): void
    {
        $this->requireOrgAdmin();
        $this->persist(null);
    }

    public function edit(string $id): void
    {
        $this->requireOrgAdmin();
        $category = $this->ownedCategory((int) $id);
        $this->render('account.categories.form', [
            'pageTitle' => 'Edit category',
            'activeNav' => 'categories',
            'category' => $category,
            'errors' => [],
            'form' => $category,
        ]);
    }

    public function update(string $id): void
    {
        $this->requireOrgAdmin();
        $this->ownedCategory((int) $id);
        $this->persist((int) $id);
    }

    public function destroy(string $id): void
    {
        $this->requireOrgAdmin();
        if (!csrfVerify(Request::post('csrf_token'))) {
            flashError('Your session expired. Please try again.');
            redirect('/account/categories');
        }
        $category = $this->ownedCategory((int) $id);
        // Super Admin deletes it on approval.
        $error = \App\Models\DeletionRequest::request('category', (int) $category['id'], (string) $category['name'], (string) ($this->user['organisation_name'] ?? ''), (int) $this->user['id'], (string) Request::post('reason', ''));
        $error === null
            ? flashSuccess('Delete request sent to Super Admin. It is deleted once Super Admin approves.')
            : flashError($error);
        redirect('/account/categories');
    }

    private function persist(?int $id): void
    {
        if (!csrfVerify(Request::post('csrf_token'))) {
            flashError('Your session expired. Please resubmit the form.');
            redirect($id ? '/account/categories/' . $id . '/edit' : '/account/categories/create');
        }

        $name = trim((string) Request::post('name', ''));
        $description = trim((string) Request::post('description', ''));
        $isActive = Request::post('is_active') === '1';
        $isOpen = Request::post('is_open') === '1';
        $sortOrder = (int) Request::post('sort_order', 0);
        $orgId = $this->organisationId();
        $errors = [];
        if ($name === '') {
            $errors[] = 'Category name is required.';
        }

        $form = [
            'name' => $name,
            'description' => $description,
            'is_active' => $isActive ? 1 : 0,
            'is_open' => $isOpen ? 1 : 0,
            'sort_order' => $sortOrder,
        ];

        if ($errors) {
            $this->render('account.categories.form', [
                'pageTitle' => $id ? 'Edit category' : 'Add category',
                'activeNav' => 'categories',
                'category' => $id ? OrganisationCategory::find($id) : null,
                'errors' => $errors,
                'form' => $form,
            ]);
            return;
        }

        $payload = [
            'organisation_id' => $orgId,
            'name' => $name,
            'slug' => OrganisationCategory::uniqueSlug($orgId, $name, $id),
            'description' => $description !== '' ? $description : null,
            'is_active' => $isActive,
            'is_open' => $isOpen,
            'sort_order' => $sortOrder,
            'branch_id' => $this->ownBranchId(),
        ];

        if ($id) {
            OrganisationCategory::update($id, $payload);
            flashSuccess('Category saved. Approved tutors for your organisation can pick it on course forms.');
        } else {
            OrganisationCategory::create($payload);
            flashSuccess('Category added. Approved tutors can now pick it when they create a course.');
        }
        redirect('/account/categories');
    }

    private function requireOrgAdmin(): void
    {
        if (Authz::isOrganisationAdmin($this->user)) {
            return;
        }
        if (($this->user['role_slug'] ?? '') === 'course_branch_admin' && $this->organisationId() > 0) {
            return;
        }
        flashError('Only organisation admins and their branch admins can manage categories.');
        redirect('/account/dashboard');
    }

    /** The organisation admin's own org, or a course branch admin's org (derived from their assigned branch). */
    private function organisationId(): int
    {
        if (!empty($this->user['organisation_id'])) {
            return (int) $this->user['organisation_id'];
        }
        if (($this->user['role_slug'] ?? '') === 'course_branch_admin') {
            $branches = OrganisationBranch::forBranchAdmin((int) $this->user['id']);
            return (int) ($branches[0]['organisation_id'] ?? 0);
        }
        return 0;
    }

    private function ownedCategory(int $id): array
    {
        $category = OrganisationCategory::find($id);
        $branchLocked = $category && !empty($category['branch_id']) && $this->isBranchAdmin() && !in_array((int) $category['branch_id'], $this->branchIds(), true);
        $orgWide = $category && empty($category['branch_id']) && $this->isBranchAdmin();
        if (!$category || (int) $category['organisation_id'] !== $this->organisationId() || $branchLocked || $orgWide) {
            flashError('That category could not be found.');
            redirect('/account/categories');
        }
        return $category;
    }

    private function isBranchAdmin(): bool
    {
        return ($this->user['role_slug'] ?? '') === 'course_branch_admin';
    }

    private function branchIds(): array
    {
        return array_map(static fn(array $b): int => (int) $b['id'], OrganisationBranch::forBranchAdmin((int) $this->user['id']));
    }

    /** A branch admin's new categories belong to their branch; an organisation admin's are organisation-wide. */
    private function ownBranchId(): ?int
    {
        return $this->isBranchAdmin() ? ($this->branchIds()[0] ?? null) : null;
    }

    private function visibleCategories(): array
    {
        return $this->isBranchAdmin()
            ? OrganisationCategory::forBranches($this->organisationId(), $this->branchIds())
            : OrganisationCategory::forOrganisation($this->organisationId());
    }

    private function blankForm(): array
    {
        return [
            'name' => '',
            'description' => '',
            'is_active' => 1,
            'is_open' => 0,
            'sort_order' => 0,
        ];
    }
}
