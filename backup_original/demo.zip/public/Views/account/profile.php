<?php
/** Requires $forms, $currentUser in scope. */
$organisationMemberships = is_array($organisationMemberships ?? null) ? $organisationMemberships : [];
$organisationStatusLabels = [
    'approved' => 'Approved',
    'pending' => 'Waiting for approval',
    'rejected' => 'Rejected',
];
$organisationSummary = [];
foreach ($organisationMemberships as $membership) {
    $name = trim((string) ($membership['organisation_name'] ?? ''));
    if ($name === '') {
        continue;
    }
    $status = (string) ($membership['status'] ?? '');
    $label = $organisationStatusLabels[$status] ?? ucfirst($status);
    $organisationSummary[] = $label !== '' ? $name . ' - ' . $label : $name;
}
if ($organisationSummary === [] && !empty($currentUser['organisation_name'])) {
    $organisationSummary[] = (string) $currentUser['organisation_name'];
}
require __DIR__ . '/layout-header.php';
?>

<div class="profile-page">
  <div class="profile-heading">
    <p class="text-xs font-black uppercase tracking-widest" style="color:var(--ke-green)">Personal information</p>
    <h1 class="mt-2 font-serif-heading text-3xl font-bold">My profile</h1>
    <p class="mt-2 text-sm font-medium" style="color:var(--ke-muted)">This is the registration form assigned to <?= e($currentUser['role_name']) ?>. Fill it in to finish signing in. You can re-edit your answers later.</p>
  </div>

  <div class="profile-layout">
    <div class="profile-form-column">
      <section class="profile-form-card rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
        <div class="border-b border-neutral-100 pb-3">
          <h2 class="font-serif-heading text-lg font-bold">Account details</h2>
          <p class="mt-1 text-xs font-semibold" style="color:var(--ke-muted)">Update your name and sign-in details separately from the assigned registration forms.</p>
        </div>
        <form method="post" action="<?= url('/account/profile') ?>" class="mt-4 grid gap-3">
          <?= csrfField() ?>
          <input type="hidden" name="account_update" value="1" />
          <?php if (!empty($currentUser['email'])): ?>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Email</label>
              <input type="email" value="<?= e($currentUser['email']) ?>" readonly class="mt-1 w-full rounded-lg border border-neutral-200 bg-neutral-100 p-2.5 text-sm text-neutral-600" />
              <p class="field-hint">Locked — use <a href="#change-request" class="underline">Request a change</a> below.</p>
            </div>
          <?php else: ?>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Email</label>
              <input type="email" name="email" value="" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="Add a sign-in email" />
            </div>
            <div>
              <button type="submit" class="btn-primary">Save account details</button>
            </div>
          <?php endif; ?>
        </form>
      </section>

      <?php
        $changeCurrent = $changeCurrent ?? [];
        $changePending = $changePending ?? null;
        $changeLatest = $changeLatest ?? null;
        $changeLabels = \App\Models\ChangeRequest::FIELDS;
      ?>
      <section id="change-request" class="profile-form-card rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
        <h2 class="text-base font-bold">Request a change</h2>
        <p class="text-xs" style="color:var(--ke-muted)">Your names, sign-in email and ID number are locked. To correct them, send a request — they change once Super Admin approves.</p>
        <?php if ($changePending): ?>
          <div class="mt-3 rounded-lg bg-amber-50 p-3 text-sm">
            <p class="font-bold">Waiting for Super Admin · sent <?= e(date('j M Y, H:i', strtotime($changePending['created_at']))) ?></p>
            <ul class="mt-1 text-xs">
              <?php foreach ($changePending['changes'] as $key => $change): ?>
                <li><?= e($changeLabels[$key] ?? $key) ?>: <s class="text-neutral-500"><?= e($change['from'] ?: '—') ?></s> → <b><?= e($change['to']) ?></b></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php else: ?>
          <?php if ($changeLatest): ?>
            <p class="mt-2 text-xs font-semibold" style="color:<?= $changeLatest['status'] === 'approved' ? 'var(--ke-green)' : 'var(--ke-red)' ?>">Your last request was <?= e($changeLatest['status']) ?><?= !empty($changeLatest['admin_note']) ? ' — ' . e($changeLatest['admin_note']) : '' ?>.</p>
          <?php endif; ?>
          <details class="mt-2">
            <summary class="cursor-pointer text-sm font-bold" style="color:var(--ke-green)">Change my details…</summary>
            <form method="post" action="<?= url('/account/profile/change-request') ?>" class="mt-3 grid gap-2 sm:grid-cols-2">
              <?= csrfField() ?>
              <?php foreach (['first_name', 'other_names', 'last_name', 'email'] as $key): ?>
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)"><?= e($changeLabels[$key]) ?>
                  <input type="<?= $key === 'email' ? 'email' : 'text' ?>" name="change[<?= $key ?>]" placeholder="<?= e(($changeCurrent[$key] ?? '') ?: 'Not set') ?>" class="mt-0.5 w-full rounded-md border border-neutral-300 p-2 text-sm normal-case font-normal">
                </label>
              <?php endforeach; ?>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">ID document
                <select name="change[id_type]" class="mt-0.5 w-full rounded-md border border-neutral-300 p-2 text-sm normal-case font-normal">
                  <option value="">Keep: <?= e(($changeCurrent['id_type'] ?? '') ?: 'not set') ?></option>
                  <?php foreach (\App\Models\FormFieldTypes::idDocumentTypes() as $doc): ?><option><?= e($doc) ?></option><?php endforeach; ?>
                </select>
              </label>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">ID / birth certificate number
                <input name="change[id_number]" maxlength="30" placeholder="<?= e(($changeCurrent['id_number'] ?? '') ?: 'Not set') ?>" class="mt-0.5 w-full rounded-md border border-neutral-300 p-2 text-sm normal-case font-normal">
              </label>
              <label class="text-[11px] font-bold uppercase sm:col-span-2" style="color:var(--ke-muted)">Why the change?
                <input name="reason" required maxlength="500" placeholder="e.g. My surname is misspelt" class="mt-0.5 w-full rounded-md border border-neutral-300 p-2 text-sm normal-case font-normal">
              </label>
              <p class="text-xs sm:col-span-2" style="color:var(--ke-muted)">Fill in only what should change; blank fields stay as they are.</p>
              <div class="sm:col-span-2"><button type="submit" class="btn-primary">Send request</button></div>
            </form>
          </details>
        <?php endif; ?>
      </section>

      <?php if (($currentUser['role_slug'] ?? '') !== 'trainer'): ?>
        <section class="profile-form-card rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
          <form method="post" action="<?= url('/account/profile/photo') ?>" enctype="multipart/form-data" class="flex flex-wrap items-center gap-4">
            <?= csrfField() ?>
            <?php if (!empty($currentUser['photo_path'])): ?>
              <img src="<?= e(imageUrl($currentUser['photo_path'])) ?>" alt="Your profile picture" class="h-16 w-16 shrink-0 rounded-full object-cover">
            <?php else: ?>
              <span class="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-neutral-100 text-neutral-400"><?= icon('user', 'h-7 w-7') ?></span>
            <?php endif; ?>
            <div class="min-w-0 flex-1">
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="photo-upload">Profile picture</label>
              <input id="photo-upload" type="file" name="photo" accept="image/jpeg,image/png,image/webp" required data-crop="1" class="mt-1 block w-full text-sm">
            </div>
            <button type="submit" class="btn-secondary">Save picture</button>
          </form>
        </section>
      <?php endif; ?>

      <?php if (($currentUser['role_slug'] ?? '') === 'trainer'):
        $missingPublic = \App\Models\User::missingPublicProfile($currentUser);
      ?>
        <section class="profile-form-card rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)" id="public-profile">
          <div class="flex items-start justify-between gap-3 border-b border-neutral-100 pb-3">
            <div>
              <h2 class="font-serif-heading text-lg font-bold">What students see</h2>
              <p class="mt-1 text-xs font-semibold" style="color:var(--ke-muted)">Students enrolled in your courses see this when they open the tutor of a course. A picture, phone number, about you and experience are required before you can create courses.</p>
            </div>
            <span class="rounded-full px-2 py-1 text-[10px] font-black uppercase <?= $missingPublic ? '' : 'text-white' ?>" style="<?= $missingPublic ? 'background:#fef2f2;color:var(--ke-red);border:1px solid var(--ke-red)' : 'background:var(--ke-green)' ?>"><?= $missingPublic ? 'Incomplete' : 'Complete' ?></span>
          </div>
          <form method="post" action="<?= url('/account/profile/public') ?>" enctype="multipart/form-data" class="mt-4 grid gap-3">
            <?= csrfField() ?>
            <div class="flex items-center gap-4">
              <?php if (!empty($currentUser['photo_path'])): ?>
                <img src="<?= e(imageUrl($currentUser['photo_path'])) ?>" alt="Your profile picture" class="h-20 w-20 shrink-0 rounded-full object-cover">
              <?php else: ?>
                <span class="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-neutral-100 text-neutral-400"><?= icon('user', 'h-8 w-8') ?></span>
              <?php endif; ?>
              <div class="min-w-0">
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-photo">Profile picture<?= empty($currentUser['photo_path']) ? ' *' : '' ?></label>
                <input id="pp-photo" type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-crop="1" class="mt-1 block w-full text-sm">
              </div>
            </div>
            <div class="grid gap-3 sm:grid-cols-2">
              <div>
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-phone">Phone number *</label>
                <input id="pp-phone" type="tel" name="phone" value="<?= e($currentUser['phone'] ?? '') ?>" required class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="0712 345 678">
              </div>
              <div>
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-headline">Title</label>
                <input id="pp-headline" type="text" name="headline" maxlength="160" value="<?= e($currentUser['headline'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="e.g. Master plumber, 12 years">
              </div>
            </div>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-bio">About you *</label>
              <textarea id="pp-bio" name="bio" rows="3" required maxlength="3000" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm"><?= e($currentUser['bio'] ?? '') ?></textarea>
            </div>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-exp">Experience *</label>
              <textarea id="pp-exp" name="experience" rows="3" required maxlength="3000" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="Where you have worked and what you have taught"><?= e($currentUser['experience'] ?? '') ?></textarea>
            </div>
            <div class="grid gap-3 sm:grid-cols-2">
              <div>
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-li">LinkedIn</label>
                <input id="pp-li" type="url" name="linkedin_url" value="<?= e($currentUser['linkedin_url'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="https://www.linkedin.com/in/…">
              </div>
              <div>
                <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)" for="pp-social">Other social media</label>
                <input id="pp-social" type="url" name="social_url" value="<?= e($currentUser['social_url'] ?? '') ?>" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="https://…">
              </div>
            </div>
            <div><button type="submit" class="btn-primary">Save what students see</button></div>
          </form>
        </section>
      <?php endif; ?>

      <?php if (!$forms): ?>
        <div class="rounded-xl border border-dashed p-8 text-sm font-bold" style="border-color:var(--ke-line);color:var(--ke-muted)">No forms have been assigned to your role yet.</div>
      <?php endif; ?>

      <?php foreach ($forms as $form):
    $answers = $form['response']['answers'] ?? [];
    $saved = !empty($form['response']['submitted_at']);
    $hasFiles = false;
    foreach ($form['fields'] as $field) {
        if (\App\Models\FormFieldTypes::isFile($field['field_type'])) {
            $hasFiles = true;
            break;
        }
    }
      ?>
        <form method="post" action="<?= url('/account/profile') ?>" <?= $hasFiles ? 'enctype="multipart/form-data"' : '' ?> class="profile-form-card rounded-xl border bg-white p-4 shadow-sm space-y-4" style="border-color:var(--ke-line)">
      <?= csrfField() ?>
      <input type="hidden" name="form_id" value="<?= (int) $form['id'] ?>" />
      <div class="flex items-start justify-between gap-3 border-b border-neutral-100 pb-3">
        <div>
          <h2 class="font-serif-heading text-lg font-bold"><?= e($form['title']) ?></h2>
          <?php if (!empty($form['description'])): ?>
            <p class="mt-1 text-sm font-medium" style="color:var(--ke-muted)"><?= e($form['description']) ?></p>
          <?php endif; ?>
        </div>
        <span class="rounded-full px-2 py-1 text-[10px] font-black uppercase <?= $saved ? 'text-white' : '' ?>" style="<?= $saved ? 'background:var(--ke-green)' : 'background:#e8f5ee;color:var(--ke-green-dark);border:1px solid var(--ke-green)' ?>">
          <?= $saved ? 'Saved' : 'Not filled' ?>
        </span>
      </div>
      <?php foreach ($form['fields'] as $field): ?>
        <div class="profile-field-row">
          <?php
            $value = $answers[$field['field_key']] ?? '';
            require __DIR__ . '/partials/field.php';
          ?>
          <?php if (!\App\Models\FormFieldTypes::isLayout($field['field_type'] ?? '')): ?>
            <button type="submit" name="save_field" value="<?= e($field['field_key']) ?>" formnovalidate class="profile-field-save btn-secondary">Save field</button>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <button type="submit" class="btn-primary"><?= $saved ? 'Update details' : 'Save details' ?></button>
        </form>
      <?php endforeach; ?>
    </div>

    <aside class="profile-details-column">
      <section class="profile-snapshot rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
        <p class="text-xs font-black uppercase tracking-widest" style="color:var(--ke-green)">Saved information</p>
        <h2 class="mt-2 font-serif-heading text-lg font-bold">Your details</h2>
        <dl class="mt-4 divide-y divide-neutral-100">
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Name</dt><dd class="mt-1 text-sm font-bold"><?= e(userFullName($currentUser)) ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Email</dt><dd class="mt-1 text-sm font-bold break-words"><?= e($currentUser['email'] ?? 'Not provided') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Phone</dt><dd class="mt-1 text-sm font-bold"><?= e(($currentUser['phone'] ?? '') ?: 'Not provided') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Role</dt><dd class="mt-1 text-sm font-bold"><?= e($currentUser['role_name'] ?? '') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Organisation</dt><dd class="mt-1 text-sm font-bold break-words"><?= e($organisationSummary ? implode(', ', $organisationSummary) : 'Not selected') ?></dd></div>
          <?php foreach ($forms as $summaryForm): ?>
            <?php foreach ($summaryForm['fields'] as $summaryField): ?>
              <?php // Name, email, phone and organisation are shown once above, from the saved account. ?>
              <?php if (\App\Models\FormFieldTypes::isLayout($summaryField['field_type'] ?? '') || in_array($summaryField['field_type'] ?? '', ['name', 'email', 'phone', 'organisation'], true)) continue; ?>
              <?php $summaryValue = $summaryForm['response']['answers'][$summaryField['field_key']] ?? ''; ?>
              <?php $summaryText = \App\Models\FormField::formatAnswer($summaryField, $summaryValue); ?>
              <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)"><?= e($summaryField['label']) ?></dt><dd class="mt-1 text-sm font-bold break-words"><?= e($summaryText) ?></dd></div>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </dl>
      </section>
    </aside>
  </div>
</div>

<script>
(function () {
  document.addEventListener('change', function (event) {
    var target = event.target;
    var field = target.closest('.js-choice-field');
    if (target.classList.contains('js-has-other') && field) {
      var selected = false;
      if (target.tagName === 'SELECT') {
        selected = target.value === '__other__';
      } else if (target.type === 'radio') {
        var checked = field.querySelector('input[type="radio"]:checked');
        selected = !!(checked && checked.value === '__other__');
      } else if (target.type === 'checkbox') {
        selected = target.checked && target.value === '__other__';
      }
      var otherInput = field.querySelector('.js-other-input');
      if (otherInput) otherInput.classList.toggle('hidden', !selected);
    }
    if (target.classList.contains('js-select-all') && field) {
      field.querySelectorAll('.js-choice-box').forEach(function (box) {
        if (box.value !== '__other__') box.checked = target.checked;
      });
    }
    if (target.classList.contains('js-range')) {
      var label = target.parentElement.querySelector('.js-range-label');
      if (label) {
        label.textContent = 'Value: ' + target.value + ' (range ' + target.min + ' – ' + target.max + ')';
      }
    }
  });

  document.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-list-row')) {
      var key = event.target.getAttribute('data-list-add');
      var holder = document.querySelector('[data-list="' + key + '"]');
      if (!holder) return;
      var first = holder.querySelector('.list-row');
      var copy = first.cloneNode(true);
      var input = copy.querySelector('input');
      if (input) input.value = '';
      holder.appendChild(copy);
    }
    if (event.target.classList.contains('remove-list-row')) {
      var holder = event.target.closest('[data-list]');
      if (!holder || holder.querySelectorAll('.list-row').length === 1) return;
      event.target.closest('.list-row').remove();
    }
    if (event.target.classList.contains('add-branch-row')) {
      var key = event.target.getAttribute('data-branches-add');
      var holder = document.querySelector('[data-branches="' + key + '"]');
      if (!holder) return;
      var first = holder.querySelector('.branch-row');
      if (!first) return;
      var copy = first.cloneNode(true);
      copy.querySelectorAll('input').forEach(function (input) {
        if (input.type === 'hidden') {
          input.remove();
          return;
        }
        input.value = '';
      });
      holder.appendChild(copy);
      holder.querySelectorAll('.branch-row').forEach(function (row, index) {
        row.querySelectorAll('input[name]').forEach(function (input) {
          input.name = input.name.replace(/answers\[[^\]]+\]\[\d+\]/, 'answers[' + key + '][' + index + ']');
        });
      });
    }
    if (event.target.classList.contains('remove-branch-row')) {
      var holder = event.target.closest('[data-branches]');
      if (!holder || holder.querySelectorAll('.branch-row').length === 1) return;
      event.target.closest('.branch-row').remove();
      var key = holder.getAttribute('data-branches');
      holder.querySelectorAll('.branch-row').forEach(function (row, index) {
        row.querySelectorAll('input[name]').forEach(function (input) {
          input.name = input.name.replace(/answers\[[^\]]+\]\[\d+\]/, 'answers[' + key + '][' + index + ']');
        });
      });
    }
  });
})();
</script>

<?php require __DIR__ . '/layout-footer.php'; ?>
