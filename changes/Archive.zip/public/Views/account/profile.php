<?php
/** Requires $forms, $currentUser in scope. */
$organisationMemberships = is_array($organisationMemberships ?? null) ? $organisationMemberships : [];
$organisationStatusLabels = [
    'approved' => 'Approved',
    'pending' => 'Waiting for approval',
    'rejected' => 'Rejected',
];
$organisationSummary = [];
foreach ($organisationMemberships as $membership) {
    $name = trim((string) ($membership['organisation_name'] ?? ''));
    if ($name === '') {
        continue;
    }
    $status = (string) ($membership['status'] ?? '');
    $label = $organisationStatusLabels[$status] ?? ucfirst($status);
    $organisationSummary[] = $label !== '' ? $name . ' - ' . $label : $name;
}
if ($organisationSummary === [] && !empty($currentUser['organisation_name'])) {
    $organisationSummary[] = (string) $currentUser['organisation_name'];
}
require __DIR__ . '/layout-header.php';
?>

<div class="profile-page">
  <div class="profile-heading">
    <p class="text-xs font-black uppercase tracking-widest" style="color:var(--ke-green)">Personal information</p>
    <h1 class="mt-2 font-serif-heading text-3xl font-bold">My profile</h1>
    <p class="mt-2 text-sm font-medium" style="color:var(--ke-muted)">This is the registration form assigned to <?= e($currentUser['role_name']) ?>. Fill it in to finish signing in. You can re-edit your answers later.</p>
  </div>

  <div class="profile-layout">
    <div class="profile-form-column">
      <section class="profile-form-card rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
        <div class="border-b border-neutral-100 pb-3">
          <h2 class="font-serif-heading text-lg font-bold">Account details</h2>
          <p class="mt-1 text-xs font-semibold" style="color:var(--ke-muted)">Update your name and sign-in details separately from the assigned registration forms.</p>
        </div>
        <form method="post" action="<?= url('/account/profile') ?>" class="mt-4 grid gap-3">
          <?= csrfField() ?>
          <input type="hidden" name="account_update" value="1" />
          <?php if (!empty($currentUser['email'])): ?>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Email</label>
              <input type="email" value="<?= e($currentUser['email']) ?>" readonly class="mt-1 w-full rounded-lg border border-neutral-200 bg-neutral-100 p-2.5 text-sm text-neutral-600" />
              <p class="field-hint">Your sign-in email can't be changed here.</p>
            </div>
          <?php else: ?>
            <div>
              <label class="text-[11px] font-bold uppercase" style="color:var(--ke-muted)">Email</label>
              <input type="email" name="email" value="" class="mt-1 w-full rounded-lg border border-neutral-300 p-2.5 text-sm" placeholder="Add a sign-in email" />
            </div>
            <div>
              <button type="submit" class="btn-primary">Save account details</button>
            </div>
          <?php endif; ?>
        </form>
      </section>

      <?php if (!$forms): ?>
        <div class="rounded-xl border border-dashed p-8 text-sm font-bold" style="border-color:var(--ke-line);color:var(--ke-muted)">No forms have been assigned to your role yet.</div>
      <?php endif; ?>

      <?php foreach ($forms as $form):
    $answers = $form['response']['answers'] ?? [];
    $saved = !empty($form['response']['submitted_at']);
    $hasFiles = false;
    foreach ($form['fields'] as $field) {
        if (\App\Models\FormFieldTypes::isFile($field['field_type'])) {
            $hasFiles = true;
            break;
        }
    }
      ?>
        <form method="post" action="<?= url('/account/profile') ?>" <?= $hasFiles ? 'enctype="multipart/form-data"' : '' ?> class="profile-form-card rounded-xl border bg-white p-4 shadow-sm space-y-4" style="border-color:var(--ke-line)">
      <?= csrfField() ?>
      <input type="hidden" name="form_id" value="<?= (int) $form['id'] ?>" />
      <div class="flex items-start justify-between gap-3 border-b border-neutral-100 pb-3">
        <div>
          <h2 class="font-serif-heading text-lg font-bold"><?= e($form['title']) ?></h2>
          <?php if (!empty($form['description'])): ?>
            <p class="mt-1 text-sm font-medium" style="color:var(--ke-muted)"><?= e($form['description']) ?></p>
          <?php endif; ?>
        </div>
        <span class="rounded-full px-2 py-1 text-[10px] font-black uppercase <?= $saved ? 'text-white' : '' ?>" style="<?= $saved ? 'background:var(--ke-green)' : 'background:#e8f5ee;color:var(--ke-green-dark);border:1px solid var(--ke-green)' ?>">
          <?= $saved ? 'Saved' : 'Not filled' ?>
        </span>
      </div>
      <?php foreach ($form['fields'] as $field): ?>
        <div class="profile-field-row">
          <?php
            $value = $answers[$field['field_key']] ?? '';
            require __DIR__ . '/partials/field.php';
          ?>
          <?php if (!\App\Models\FormFieldTypes::isLayout($field['field_type'] ?? '')): ?>
            <button type="submit" name="save_field" value="<?= e($field['field_key']) ?>" formnovalidate class="profile-field-save btn-secondary">Save field</button>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <button type="submit" class="btn-primary"><?= $saved ? 'Update details' : 'Save details' ?></button>
        </form>
      <?php endforeach; ?>
    </div>

    <aside class="profile-details-column">
      <section class="profile-snapshot rounded-xl border bg-white p-4 shadow-sm" style="border-color:var(--ke-line)">
        <p class="text-xs font-black uppercase tracking-widest" style="color:var(--ke-green)">Saved information</p>
        <h2 class="mt-2 font-serif-heading text-lg font-bold">Your details</h2>
        <dl class="mt-4 divide-y divide-neutral-100">
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Name</dt><dd class="mt-1 text-sm font-bold"><?= e(userDisplayName($currentUser)) ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Email</dt><dd class="mt-1 text-sm font-bold break-words"><?= e($currentUser['email'] ?? 'Not provided') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Phone</dt><dd class="mt-1 text-sm font-bold"><?= e($currentUser['phone'] ?? 'Not provided') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Role</dt><dd class="mt-1 text-sm font-bold"><?= e($currentUser['role_name'] ?? '') ?></dd></div>
          <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)">Organisation</dt><dd class="mt-1 text-sm font-bold break-words"><?= e($organisationSummary ? implode(', ', $organisationSummary) : 'Not selected') ?></dd></div>
          <?php foreach ($forms as $summaryForm): ?>
            <?php foreach ($summaryForm['fields'] as $summaryField): ?>
              <?php if (\App\Models\FormFieldTypes::isLayout($summaryField['field_type'] ?? '')) continue; ?>
              <?php $summaryValue = $summaryForm['response']['answers'][$summaryField['field_key']] ?? ''; ?>
              <?php $summaryText = \App\Models\FormField::formatAnswer($summaryField, $summaryValue); ?>
              <div class="py-3"><dt class="text-[10px] font-bold uppercase" style="color:var(--ke-muted)"><?= e($summaryField['label']) ?></dt><dd class="mt-1 text-sm font-bold break-words"><?= e($summaryText) ?></dd></div>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </dl>
      </section>
    </aside>
  </div>
</div>

<script>
(function () {
  document.addEventListener('change', function (event) {
    var target = event.target;
    var field = target.closest('.js-choice-field');
    if (target.classList.contains('js-has-other') && field) {
      var selected = false;
      if (target.tagName === 'SELECT') {
        selected = target.value === '__other__';
      } else if (target.type === 'radio') {
        var checked = field.querySelector('input[type="radio"]:checked');
        selected = !!(checked && checked.value === '__other__');
      } else if (target.type === 'checkbox') {
        selected = target.checked && target.value === '__other__';
      }
      var otherInput = field.querySelector('.js-other-input');
      if (otherInput) otherInput.classList.toggle('hidden', !selected);
    }
    if (target.classList.contains('js-select-all') && field) {
      field.querySelectorAll('.js-choice-box').forEach(function (box) {
        if (box.value !== '__other__') box.checked = target.checked;
      });
    }
    if (target.classList.contains('js-range')) {
      var label = target.parentElement.querySelector('.js-range-label');
      if (label) {
        label.textContent = 'Value: ' + target.value + ' (range ' + target.min + ' – ' + target.max + ')';
      }
    }
  });

  document.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-list-row')) {
      var key = event.target.getAttribute('data-list-add');
      var holder = document.querySelector('[data-list="' + key + '"]');
      if (!holder) return;
      var first = holder.querySelector('.list-row');
      var copy = first.cloneNode(true);
      var input = copy.querySelector('input');
      if (input) input.value = '';
      holder.appendChild(copy);
    }
    if (event.target.classList.contains('remove-list-row')) {
      var holder = event.target.closest('[data-list]');
      if (!holder || holder.querySelectorAll('.list-row').length === 1) return;
      event.target.closest('.list-row').remove();
    }
    if (event.target.classList.contains('add-branch-row')) {
      var key = event.target.getAttribute('data-branches-add');
      var holder = document.querySelector('[data-branches="' + key + '"]');
      if (!holder) return;
      var first = holder.querySelector('.branch-row');
      if (!first) return;
      var copy = first.cloneNode(true);
      copy.querySelectorAll('input').forEach(function (input) {
        if (input.type === 'hidden') {
          input.remove();
          return;
        }
        input.value = '';
      });
      holder.appendChild(copy);
      holder.querySelectorAll('.branch-row').forEach(function (row, index) {
        row.querySelectorAll('input[name]').forEach(function (input) {
          input.name = input.name.replace(/answers\[[^\]]+\]\[\d+\]/, 'answers[' + key + '][' + index + ']');
        });
      });
    }
    if (event.target.classList.contains('remove-branch-row')) {
      var holder = event.target.closest('[data-branches]');
      if (!holder || holder.querySelectorAll('.branch-row').length === 1) return;
      event.target.closest('.branch-row').remove();
      var key = holder.getAttribute('data-branches');
      holder.querySelectorAll('.branch-row').forEach(function (row, index) {
        row.querySelectorAll('input[name]').forEach(function (input) {
          input.name = input.name.replace(/answers\[[^\]]+\]\[\d+\]/, 'answers[' + key + '][' + index + ']');
        });
      });
    }
  });
})();
</script>

<?php require __DIR__ . '/layout-footer.php'; ?>
